import json

def lambda_handler(event, context):
    
    first_name = event['firstname']
    last_name = event['lastname']
    
    return {
        'statusCode': 200,
        'body': json.dumps(f'Hello {first_name} {last_name}')
    }
